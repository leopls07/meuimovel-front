import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

function Spinner() {
  return (
    <span
      className="mr-2 inline-block h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white"
      aria-hidden="true"
    />
  )
}

function num(v) {
  if (v === '' || v == null) return null
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}

export default function SimulacaoForm({ initialData, onSubmit, onCancel, submitLabel = 'Salvar' }) {
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    entrada: initialData?.entrada ?? '',
    taxaJurosAnual: initialData?.taxaJurosAnual != null ? Number(initialData.taxaJurosAnual) * 100 : '',
    prazoMeses: initialData?.prazoMeses ?? '',
    amortizacaoExtraMes: initialData?.amortizacaoExtraMes ?? '',
  })

  function setField(key) {
    return (e) => setForm((f) => ({ ...f, [key]: e.target.value }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    try {
      const payload = {
        entrada: num(form.entrada),
        taxaJurosAnual: num(form.taxaJurosAnual) != null ? num(form.taxaJurosAnual) / 100 : null,
        prazoMeses: num(form.prazoMeses),
        amortizacaoExtraMes: num(form.amortizacaoExtraMes),
      }
      await onSubmit?.(payload)
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card className="bg-white shadow-sm rounded-2xl">
      <CardHeader>
        <CardTitle className="text-base">Simulação</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <Label>Entrada</Label>
              <Input type="number" placeholder="0,00" value={form.entrada} onChange={setField('entrada')} />
            </div>
            <div>
              <Label>Taxa de juros anual (%)</Label>
              <Input type="number" placeholder="12" value={form.taxaJurosAnual} onChange={setField('taxaJurosAnual')} />
              <div className="mt-1 text-xs text-slate-500">Ex.: 12 → enviado como 0.12</div>
            </div>
            <div>
              <Label>Prazo (meses)</Label>
              <Input type="number" placeholder="360" value={form.prazoMeses} onChange={setField('prazoMeses')} />
            </div>
            <div>
              <Label>Amortização extra/mês</Label>
              <Input type="number" placeholder="0,00" value={form.amortizacaoExtraMes} onChange={setField('amortizacaoExtraMes')} />
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button type="submit" className="bg-primary-600 hover:bg-primary-700 text-white" disabled={saving}>
              {saving && <Spinner />} {saving ? 'Salvando...' : submitLabel}
            </Button>
            <Button
              type="button"
              variant="outline"
              className="border-primary-600 text-primary-600 hover:bg-primary-50"
              onClick={onCancel}
              disabled={saving}
            >
              Cancelar
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

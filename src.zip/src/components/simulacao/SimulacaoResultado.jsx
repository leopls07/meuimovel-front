import { formatBRL, formatPct } from '@/utils/formatters'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

function Field({ label, value, highlight }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-4">
      <div className="text-xs text-slate-500">{label}</div>
      <div className={highlight ? 'text-primary-700 font-semibold' : 'text-slate-800 font-semibold'}>
        {value}
      </div>
    </div>
  )
}

export default function SimulacaoResultado({ simulacao }) {
  if (!simulacao) return null

  return (
    <Card className="bg-white shadow-sm rounded-2xl">
      <CardHeader>
        <CardTitle className="text-base">Resultado da simulação</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Valor financiado" value={formatBRL(simulacao.valorFinanciado)} highlight />
          <Field label="Parcela mensal (Price)" value={formatBRL(simulacao.parcelaMensalPrice)} highlight />
          <Field label="Pagamento total/mês" value={formatBRL(simulacao.pagamentoTotalMes)} />

          <Field label="Nº parcelas efetivas" value={simulacao.parcelasEfetivas ?? '—'} />
          <Field label="Tempo de pagamento (anos)" value={simulacao.tempoPagamentoAnos ?? '—'} />
          <Field label="Custo total mensal" value={formatBRL(simulacao.custoTotalMensal)} />

          <Field label="Total pago" value={formatBRL(simulacao.totalPago)} />
          <Field label="Total de juros" value={formatBRL(simulacao.totalJuros)} />
          <Field label="Juros % do financiado" value={formatPct(simulacao.jurosPctFinanciado)} />
        </div>
      </CardContent>
    </Card>
  )
}

import { Link } from 'react-router-dom'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { formatBRL, formatM2 } from '@/utils/formatters'
import { Car, Ruler, BedDouble, Trash2, Eye } from 'lucide-react'

function safeNumber(v) {
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}

export default function ImovelCard({ imovel, onRemove }) {
  const preco = safeNumber(imovel?.preco)
  const metragem = safeNumber(imovel?.metragem)
  const precoM2 = preco != null && metragem ? preco / metragem : null
  const custoFixo = (safeNumber(imovel?.condominioMensal) || 0) + (safeNumber(imovel?.iptuMensal) || 0)
  const hasSimulacao = Boolean(imovel?.simulacao || imovel?.temSimulacao)

  return (
    <Card className="bg-white shadow-sm rounded-2xl">
      <CardHeader className="space-y-2">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold text-slate-800">
              {imovel?.localizacao || '—'}
            </div>
            <div className="text-xs text-slate-500">ID: {imovel?.id ?? '—'}</div>
          </div>
          <Badge
            className={
              hasSimulacao
                ? 'bg-primary-50 text-primary-700 hover:bg-primary-50'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-100'
            }
          >
            {hasSimulacao ? 'Com simulação' : 'Sem simulação'}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="text-2xl text-primary-700 font-semibold">{formatBRL(preco)}</div>
        <div className="flex flex-wrap gap-2 text-xs">
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-1 text-slate-700">
            <BedDouble className="h-3.5 w-3.5" /> {imovel?.quartos ?? '—'}
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-1 text-slate-700">
            <Car className="h-3.5 w-3.5" /> {imovel?.vagas ?? '—'}
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-1 text-slate-700">
            <Ruler className="h-3.5 w-3.5" /> {formatM2(metragem)}
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-1 text-slate-700">
            Preço/m²: {precoM2 != null ? formatBRL(precoM2) : '—'}
          </span>
        </div>
        <div className="text-sm text-slate-600">
          Custo fixo mensal: <span className="text-slate-800 font-medium">{formatBRL(custoFixo || null)}</span>
        </div>
      </CardContent>

      <CardFooter className="flex items-center justify-between gap-3">
        <Button asChild variant="outline" className="border-primary-600 text-primary-600 hover:bg-primary-50">
          <Link to={`/imoveis/${imovel?.id}`}>
            <Eye className="mr-2 h-4 w-4" /> Ver detalhes
          </Link>
        </Button>

        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-red-500 hover:bg-red-600 text-white">
              <Trash2 className="mr-2 h-4 w-4" /> Remover
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Remover imóvel?</DialogTitle>
              <DialogDescription>
                Essa ação não pode ser desfeita. O imóvel será excluído permanentemente.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline">Cancelar</Button>
              <Button
                className="bg-red-500 hover:bg-red-600 text-white"
                onClick={() => onRemove?.(imovel?.id)}
              >
                Confirmar remoção
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardFooter>
    </Card>
  )
}

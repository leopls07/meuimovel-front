import { useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

function toNumberOrNull(v) {
  if (v === '' || v == null) return null
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}

export default function FiltrosBusca({ onSearch, onClear, disabled }) {
  const [open, setOpen] = useState(true)
  const [form, setForm] = useState({
    localizacao: '',
    precoMin: '',
    precoMax: '',
    metMin: '',
    quartos: '',
    vagas: '',
    areaLazer: false,
    vagaCoberta: false,
    distMaxMetro: '',
    notaMinLoc: '',
  })

  const params = useMemo(() => {
    const p = {
      localizacao: form.localizacao?.trim() || null,
      precoMin: toNumberOrNull(form.precoMin),
      precoMax: toNumberOrNull(form.precoMax),
      metMin: toNumberOrNull(form.metMin),
      quartos: toNumberOrNull(form.quartos),
      vagas: toNumberOrNull(form.vagas),
      areaLazer: form.areaLazer ? true : null,
      vagaCoberta: form.vagaCoberta ? true : null,
      distMaxMetro: toNumberOrNull(form.distMaxMetro),
      notaMinLoc: toNumberOrNull(form.notaMinLoc),
    }
    Object.keys(p).forEach((k) => {
      if (p[k] == null || p[k] === '') delete p[k]
    })
    return p
  }, [form])

  const hasAnyFilter = Object.keys(params).length > 0

  function handleChange(key) {
    return (e) => {
      const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value
      setForm((f) => ({ ...f, [key]: value }))
    }
  }

  return (
    <Card className="bg-white shadow-sm rounded-2xl">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base">Filtros</CardTitle>
        <Button
          type="button"
          variant="outline"
          className="border-primary-600 text-primary-600 hover:bg-primary-50"
          onClick={() => setOpen((o) => !o)}
        >
          {open ? 'Recolher' : 'Expandir'}
        </Button>
      </CardHeader>
      {open && (
        <CardContent>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div className="md:col-span-3">
              <Label>Localização</Label>
              <Input value={form.localizacao} onChange={handleChange('localizacao')} placeholder="Ex: Vila Mariana, SP" />
            </div>

            <div>
              <Label>Preço mín.</Label>
              <Input type="number" placeholder="0" value={form.precoMin} onChange={handleChange('precoMin')} />
            </div>
            <div>
              <Label>Preço máx.</Label>
              <Input type="number" placeholder="0" value={form.precoMax} onChange={handleChange('precoMax')} />
            </div>
            <div>
              <Label>Metragem mín. (m²)</Label>
              <Input type="number" placeholder="0" value={form.metMin} onChange={handleChange('metMin')} />
            </div>

            <div>
              <Label>Quartos</Label>
              <Input type="number" placeholder="0" value={form.quartos} onChange={handleChange('quartos')} />
            </div>
            <div>
              <Label>Vagas</Label>
              <Input type="number" placeholder="0" value={form.vagas} onChange={handleChange('vagas')} />
            </div>
            <div>
              <Label>Distância máx. metrô (km)</Label>
              <Input type="number" placeholder="0" value={form.distMaxMetro} onChange={handleChange('distMaxMetro')} />
            </div>

            <div>
              <Label>Nota mín. localização</Label>
              <Input type="number" placeholder="0" value={form.notaMinLoc} onChange={handleChange('notaMinLoc')} />
            </div>
            <div className="flex items-end gap-3 md:col-span-2">
              <label className="flex items-center gap-2 text-sm text-slate-600">
                <input type="checkbox" checked={form.areaLazer} onChange={handleChange('areaLazer')} />
                Área de lazer
              </label>
              <label className="flex items-center gap-2 text-sm text-slate-600">
                <input type="checkbox" checked={form.vagaCoberta} onChange={handleChange('vagaCoberta')} />
                Vaga coberta
              </label>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <Button
              type="button"
              className="bg-primary-600 hover:bg-primary-700 text-white"
              disabled={disabled}
              onClick={() => onSearch(hasAnyFilter ? params : null)}
            >
              Buscar
            </Button>

            <Button
              type="button"
              variant="outline"
              className="border-primary-600 text-primary-600 hover:bg-primary-50"
              onClick={() => {
                setForm({
                  localizacao: '',
                  precoMin: '',
                  precoMax: '',
                  metMin: '',
                  quartos: '',
                  vagas: '',
                  areaLazer: false,
                  vagaCoberta: false,
                  distMaxMetro: '',
                  notaMinLoc: '',
                })
                onClear?.()
              }}
            >
              Limpar filtros
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  )
}

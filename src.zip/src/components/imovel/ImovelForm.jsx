import { useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

function Spinner() {
  return (
    <span
      className="mr-2 inline-block h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white"
      aria-hidden="true"
    />
  )
}

function numberOrNull(v) {
  if (v === '' || v == null) return null
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}

function calcularIptuMensal(precoValor, aliquotaValor) {
  const preco = numberOrNull(precoValor)
  const aliquota = numberOrNull(aliquotaValor)
  if (preco == null || aliquota == null) return null
  const iptuAnual = preco * (aliquota / 100)
  const iptuMensal = iptuAnual / 12
  return iptuMensal
}

function buildInitial(mode, initialData) {
  const base = {
    localizacao: '',
    metragem: '',
    quartos: '',
    vagas: '',
    qtdBanheiros: '',
    andar: '',
    anoConstrucao: '',
    areaLazer: false,
    vagaCoberta: false,
    varanda: false,
    preco: '',
    condominioMensal: '',
    iptuMensal: '',
    aliquotaIptu: '',
    distanciaMetroKm: '',
    notaLocalizacao: '',
    estadoConservacao: '',
    observacoes: '',
  }

  if (!initialData) return base

  const merged = { ...base, ...initialData }

  if (mode === 'patch') {
    // In patch mode, keep empty by default (optional fields)
    Object.keys(base).forEach((k) => {
      merged[k] = ''
    })
    ;['areaLazer', 'vagaCoberta', 'varanda'].forEach((k) => {
      merged[k] = false
    })
  }

  return merged
}

export default function ImovelForm({
  mode = 'create',
  initialData,
  onSubmit,
  onCancel,
  submitLabel = 'Salvar',
}) {
  const [saving, setSaving] = useState(false)
  const [errors, setErrors] = useState({})
  const [form, setForm] = useState(() => buildInitial(mode, initialData))

  const computed = useMemo(() => {
    const preco = numberOrNull(form.preco)
    const met = numberOrNull(form.metragem)
    const iptuMensalCalculado = calcularIptuMensal(form.preco, form.aliquotaIptu)
    const custoFixo =
      (numberOrNull(form.condominioMensal) || 0) + (iptuMensalCalculado || 0)
    return {
      precoM2: preco != null && met ? preco / met : null,
      custoFixo,
      iptuMensalCalculado,
    }
  }, [form])

  function setField(key) {
    return (e) => {
      const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value
      setForm((f) => {
        const next = { ...f, [key]: value }
        // Recalcula IPTU mensal sempre que preço ou alíquota mudarem
        if (key === 'preco' || key === 'aliquotaIptu') {
          const iptuMensal = calcularIptuMensal(next.preco, next.aliquotaIptu)
          next.iptuMensal = iptuMensal != null ? iptuMensal.toFixed(2) : ''
        }
        return next
      })
      setErrors((prev) => ({ ...prev, [key]: undefined }))
    }
  }

  function applyValidationErrors(validationErrors) {
    const next = {}
    validationErrors.forEach((e) => {
      next[e.field] = e.message
    })
    setErrors(next)
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    setErrors({})

    const payload = {
      localizacao: form.localizacao || undefined,
      metragem: numberOrNull(form.metragem),
      quartos: numberOrNull(form.quartos),
      vagas: numberOrNull(form.vagas),
      qtdBanheiros: numberOrNull(form.qtdBanheiros),
      andar: numberOrNull(form.andar),
      anoConstrucao: numberOrNull(form.anoConstrucao),
      areaLazer: form.areaLazer || undefined,
      vagaCoberta: form.vagaCoberta || undefined,
      varanda: form.varanda || undefined,
      preco: numberOrNull(form.preco),
      condominioMensal: numberOrNull(form.condominioMensal),
      iptuMensal: computed.iptuMensalCalculado ?? null,
      aliquotaIptu: numberOrNull(form.aliquotaIptu),
      distanciaMetroKm: numberOrNull(form.distanciaMetroKm),
      notaLocalizacao: numberOrNull(form.notaLocalizacao),
      estadoConservacao: numberOrNull(form.estadoConservacao),
      observacoes: form.observacoes || undefined,
    }

    if (mode === 'patch') {
      Object.keys(payload).forEach((k) => {
        if (payload[k] == null || payload[k] === '' || payload[k] === false) delete payload[k]
      })
    }

    try {
      await onSubmit?.(payload, applyValidationErrors)
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card className="bg-white shadow-sm rounded-2xl">
      <CardHeader>
        <CardTitle className="text-base">
          {mode === 'patch' ? 'Editar imóvel' : 'Dados do imóvel'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-7">
          <section className="space-y-3">
            <div className="text-sm font-semibold text-slate-800">Localização</div>
            <div>
              <Label>Localização</Label>
              <Input value={form.localizacao} onChange={setField('localizacao')} placeholder="Rua, bairro, cidade" />
              {errors.localizacao && <div className="mt-1 text-xs text-red-600">{errors.localizacao}</div>}
            </div>
          </section>

          <section className="space-y-3">
            <div className="text-sm font-semibold text-slate-800">Características</div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {[
                ['metragem', 'Metragem (m²)'],
                ['quartos', 'Quartos'],
                ['vagas', 'Vagas'],
                ['qtdBanheiros', 'Banheiros'],
                ['andar', 'Andar'],
                ['anoConstrucao', 'Ano de construção'],
              ].map(([k, label]) => (
                <div key={k}>
                  <Label>{label}</Label>
                  <Input type="number" value={form[k]} onChange={setField(k)} placeholder="0" />
                  {errors[k] && <div className="mt-1 text-xs text-red-600">{errors[k]}</div>}
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-5">
              {[
                ['areaLazer', 'Área de lazer'],
                ['vagaCoberta', 'Vaga coberta'],
                ['varanda', 'Varanda'],
              ].map(([k, label]) => (
                <label key={k} className="flex items-center gap-2 text-sm text-slate-600">
                  <input type="checkbox" checked={form[k]} onChange={setField(k)} />
                  {label}
                </label>
              ))}
            </div>
          </section>

          <section className="space-y-3">
            <div className="text-sm font-semibold text-slate-800">Financeiro</div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <Label>Preço</Label>
                <Input type="number" placeholder="0,00" value={form.preco} onChange={setField('preco')} />
                {errors.preco && <div className="mt-1 text-xs text-red-600">{errors.preco}</div>}
              </div>
              <div>
                <Label>Condomínio mensal</Label>
                <Input type="number" placeholder="0,00" value={form.condominioMensal} onChange={setField('condominioMensal')} />
                {errors.condominioMensal && <div className="mt-1 text-xs text-red-600">{errors.condominioMensal}</div>}
              </div>
              <div>
                <Label>IPTU mensal</Label>
                <Input
                  type="number"
                  placeholder="0,00"
                  value={form.iptuMensal}
                  readOnly
                />
                <div className="mt-1 text-xs text-slate-500">
                  Calculado automaticamente: (preço × alíquota anual) ÷ 12.
                </div>
              </div>
              <div>
                <Label>Alíquota IPTU (opcional)</Label>
                <Input type="number" placeholder="0" value={form.aliquotaIptu} onChange={setField('aliquotaIptu')} />
                {errors.aliquotaIptu && <div className="mt-1 text-xs text-red-600">{errors.aliquotaIptu}</div>}
              </div>
              <div>
                <Label>Distância do metrô (km)</Label>
                <Input type="number" placeholder="0" value={form.distanciaMetroKm} onChange={setField('distanciaMetroKm')} />
                {errors.distanciaMetroKm && <div className="mt-1 text-xs text-red-600">{errors.distanciaMetroKm}</div>}
              </div>
              <div className="rounded-xl bg-slate-50 p-3">
                <div className="text-xs text-slate-500">Preço/m² (calculado)</div>
                <div className="text-sm font-semibold text-primary-700">
                  {computed.precoM2 != null ? computed.precoM2.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '—'}
                </div>
                <div className="mt-2 text-xs text-slate-500">Custo fixo mensal (condomínio + IPTU)</div>
                <div className="text-sm font-semibold text-slate-800">
                  {computed.custoFixo ? computed.custoFixo.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '—'}
                </div>
              </div>
            </div>
          </section>

          <section className="space-y-3">
            <div className="text-sm font-semibold text-slate-800">Avaliação</div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <Label>Nota localização (1-10)</Label>
                <Input type="number" value={form.notaLocalizacao} onChange={setField('notaLocalizacao')} placeholder="0" />
                {errors.notaLocalizacao && <div className="mt-1 text-xs text-red-600">{errors.notaLocalizacao}</div>}
              </div>
              <div>
                <Label>Estado de conservação (1-5)</Label>
                <Input type="number" value={form.estadoConservacao} onChange={setField('estadoConservacao')} placeholder="0" />
                {errors.estadoConservacao && <div className="mt-1 text-xs text-red-600">{errors.estadoConservacao}</div>}
              </div>
              <div className="sm:col-span-2">
                <Label>Observações</Label>
                <Input value={form.observacoes} onChange={setField('observacoes')} placeholder="Detalhes adicionais" />
                {errors.observacoes && <div className="mt-1 text-xs text-red-600">{errors.observacoes}</div>}
              </div>
            </div>
          </section>

          <div className="flex flex-wrap gap-3">
            <Button
              type="submit"
              variant="default"
              className="w-full sm:w-auto"
              disabled={saving}
            >
              {saving && <Spinner />} {saving ? 'Salvando...' : submitLabel}
            </Button>
            <Button
              type="button"
              variant="outline"
              className="w-full sm:w-auto border-primary-600 text-primary-600 hover:bg-primary-50"
              onClick={onCancel}
              disabled={saving}
            >
              Cancelar
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

import { Menu } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import SidebarNav from './SidebarNav'

export default function Header({ title }) {
  return (
    <header className="sticky top-0 z-10 border-b border-slate-200 bg-white">
      <div className="flex h-16 items-center justify-between gap-3 px-4 sm:px-6">
        <div className="flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="md:hidden border-slate-200"
                aria-label="Abrir menu"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0">
              <SidebarNav variant="mobile" />
            </SheetContent>
          </Sheet>

          <h1 className="text-lg font-semibold text-slate-800 sm:text-xl">
            {title}
          </h1>
        </div>

        <div className="text-sm text-slate-500">Cadastro & análise de imóveis</div>
      </div>
    </header>
  )
}

import SidebarNav from './SidebarNav'

export default function Sidebar() {
  return (
    <aside className="hidden w-60 shrink-0 border-r border-slate-200 bg-white md:block">
      <SidebarNav />
    </aside>
  )
}

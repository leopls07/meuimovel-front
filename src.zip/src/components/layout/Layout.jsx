import { Outlet, useLocation } from 'react-router-dom'
import Sidebar from './Sidebar'
import Header from './Header'

const TITLES = [
  { match: /^\/imoveis$/, title: 'Imóveis' },
  { match: /^\/imoveis\/novo$/, title: 'Cadastrar imóvel' },
  { match: /^\/imoveis\/.+/, title: 'Detalhe do imóvel' },
]

function usePageTitle() {
  const { pathname } = useLocation()
  const found = TITLES.find((t) => t.match.test(pathname))
  return found?.title || 'meuimovel'
}

export default function Layout() {
  const title = usePageTitle()

  return (
    <div className="min-h-svh bg-slate-50">
      <div className="mx-auto flex min-h-svh max-w-screen-2xl">
        <Sidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <Header title={title} />
          <main className="flex-1 p-4 sm:p-6">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  )
}

import { NavLink } from 'react-router-dom'
import { Building2, Home, Plus } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Separator } from '@/components/ui/separator'

// eslint-disable-next-line no-unused-vars
function Item({ to, icon: _ICON, children, end }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        cn(
          'flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-600 hover:bg-slate-50',
          isActive && 'bg-primary-50 text-primary-700 font-semibold'
        )
      }
    >
  <_ICON className="h-4 w-4" />
      <span>{children}</span>
    </NavLink>
  )
}

export default function SidebarNav({ variant = 'desktop' } = {}) {
  return (
    <div className={cn('flex h-full flex-col', variant === 'mobile' && 'pt-2')}>
      <div className="px-4 py-4">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-primary-50 text-primary-700">
            <Home className="h-5 w-5" />
          </div>
          <div className="leading-tight">
            <div className="font-semibold text-slate-800">meuimovel</div>
            <div className="text-xs text-slate-500">Frontend</div>
          </div>
        </div>
      </div>

      <Separator />

      <nav className="flex flex-col gap-1 px-3 py-3">
        <Item to="/imoveis" icon={Building2} end>
          Imóveis
        </Item>
        <Item to="/imoveis/novo" icon={Plus}>
          Novo imóvel
        </Item>
      </nav>

      <div className="mt-auto px-4 py-4 text-xs text-slate-400">
        API: {import.meta.env.VITE_API_URL || 'http://localhost:8080'}
      </div>
    </div>
  )
}

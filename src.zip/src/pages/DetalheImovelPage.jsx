import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Edit3, Trash2, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Skeleton } from '@/components/ui/skeleton'
import ImovelPatchForm from '@/components/imovel/ImovelPatchForm'
import SimulacaoForm from '@/components/simulacao/SimulacaoForm'
import SimulacaoResultado from '@/components/simulacao/SimulacaoResultado'
import { useImoveis } from '@/hooks/useImoveis'
import { useSimulacao } from '@/hooks/useSimulacao'
import { formatBRL } from '@/utils/formatters'

function kv(obj) {
  if (!obj) return []
  return Object.entries(obj)
}

export default function DetalheImovelPage() {
  const { id } = useParams()
  const navigate = useNavigate()

  const { getById, patch, remove } = useImoveis({ autoLoad: false })
  const simulacao = useSimulacao(id)

  const [loading, setLoading] = useState(true)
  const [data, setData] = useState(null)

  useEffect(() => {
    let ignore = false
    async function run() {
      setLoading(true)
      try {
        const d = await getById(id)
        if (!ignore) setData(d)
      } finally {
        if (!ignore) setLoading(false)
      }
    }
    run()
    return () => {
      ignore = true
    }
  }, [id, getById])

  const computed = useMemo(() => {
    const preco = Number(data?.preco)
    const metragem = Number(data?.metragem)
    const precoM2 = Number.isFinite(preco) && Number.isFinite(metragem) && metragem ? preco / metragem : null
    const custoFixo = (Number(data?.condominioMensal) || 0) + (Number(data?.iptuMensal) || 0)
    return { precoM2, custoFixo }
  }, [data])

  const hasSimulacao = Boolean(simulacao.data)

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-1/2" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-44 w-full" />
      </div>
    )
  }

  if (!data) {
    return (
      <Card className="bg-white shadow-sm rounded-2xl">
        <CardHeader>
          <CardTitle>Imóvel não encontrado</CardTitle>
        </CardHeader>
        <CardContent>
          <Button variant="outline" className="border-primary-600 text-primary-600 hover:bg-primary-50" onClick={() => navigate('/imoveis')}>
            Voltar
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <section className="space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="text-xl font-semibold text-slate-800">{data.localizacao}</div>
            <div className="mt-1">
              <Badge className={hasSimulacao ? 'bg-primary-50 text-primary-700 hover:bg-primary-50' : 'bg-slate-100 text-slate-600 hover:bg-slate-100'}>
                {hasSimulacao ? 'Com simulação' : 'Sem simulação'}
              </Badge>
            </div>
          </div>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="default">
                <Edit3 className="mr-2 h-4 w-4" /> Editar
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full sm:max-w-xl overflow-y-auto">
              <SheetHeader>
                <SheetTitle>Editar imóvel</SheetTitle>
              </SheetHeader>
              <div className="mt-4">
                <ImovelPatchForm
                  onCancel={() => {}}
                  onSubmit={async (payload, applyValidationErrors) => {
                    const updated = await patch(id, payload, { onValidationErrors: applyValidationErrors })
                    if (updated) {
                      setData(updated)
                    }
                  }}
                />
              </div>
            </SheetContent>
          </Sheet>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="rounded-2xl bg-white shadow-sm p-4">
            <div className="text-xs text-slate-500">Preço</div>
            <div className="text-primary-700 font-semibold text-lg">{formatBRL(data.preco)}</div>
          </div>
          <div className="rounded-2xl bg-white shadow-sm p-4">
            <div className="text-xs text-slate-500">Preço/m² (calculado)</div>
            <div className="text-slate-800 font-semibold text-lg">{computed.precoM2 != null ? formatBRL(computed.precoM2) : '—'}</div>
          </div>
          <div className="rounded-2xl bg-white shadow-sm p-4">
            <div className="text-xs text-slate-500">Custo fixo mensal</div>
            <div className="text-slate-800 font-semibold text-lg">{formatBRL(computed.custoFixo || null)}</div>
          </div>
        </div>

        <Card className="bg-white shadow-sm rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base">Campos do imóvel</CardTitle>

            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-red-500 hover:bg-red-600 text-white">
                  <Trash2 className="mr-2 h-4 w-4" /> Remover
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Remover imóvel?</DialogTitle>
                  <DialogDescription>Essa ação não pode ser desfeita.</DialogDescription>
                </DialogHeader>
                <DialogFooter>
                  <Button variant="outline">Cancelar</Button>
                  <Button
                    className="bg-red-500 hover:bg-red-600 text-white"
                    onClick={async () => {
                      const ok = await remove(id)
                      if (ok) navigate('/imoveis')
                    }}
                  >
                    Confirmar remoção
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {kv(data).map(([k, v]) => (
                <div key={k} className="rounded-xl bg-slate-50 px-3 py-2">
                  <div className="text-xs text-slate-500">{k}</div>
                  <div className="text-sm font-medium text-slate-800 break-words">
                    {v == null ? '—' : String(v)}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </section>

      <section className="space-y-4">
        <div className="text-lg font-semibold text-slate-800">Simulação de financiamento</div>

        {!hasSimulacao ? (
          <Card className="bg-white shadow-sm rounded-2xl">
            <CardContent className="p-8 text-center">
              <div className="text-sm text-slate-500">Nenhuma simulação cadastrada.</div>
              <div className="mt-4">
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="default">
                      <Plus className="mr-2 h-4 w-4" /> Criar simulação
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="right" className="w-full sm:max-w-xl overflow-y-auto">
                    <SheetHeader>
                      <SheetTitle>Criar simulação</SheetTitle>
                    </SheetHeader>
                    <div className="mt-4">
                      <SimulacaoForm
                        onCancel={() => {}}
                        onSubmit={async (payload) => {
                          await simulacao.create(payload)
                        }}
                      />
                    </div>
                  </SheetContent>
                </Sheet>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-3">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="default">
                    <Edit3 className="mr-2 h-4 w-4" /> Editar simulação
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-full sm:max-w-xl overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Editar simulação</SheetTitle>
                  </SheetHeader>
                  <div className="mt-4">
                    <SimulacaoForm
                      initialData={simulacao.data}
                      submitLabel="Salvar"
                      onCancel={() => {}}
                      onSubmit={async (payload) => {
                        await simulacao.patch(payload)
                      }}
                    />
                  </div>
                </SheetContent>
              </Sheet>

              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-red-500 hover:bg-red-600 text-white">
                    <Trash2 className="mr-2 h-4 w-4" /> Remover simulação
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Remover simulação?</DialogTitle>
                    <DialogDescription>Essa ação não pode ser desfeita.</DialogDescription>
                  </DialogHeader>
                  <DialogFooter>
                    <Button variant="outline">Cancelar</Button>
                    <Button
                      className="bg-red-500 hover:bg-red-600 text-white"
                      onClick={async () => {
                        await simulacao.remove()
                      }}
                    >
                      Confirmar remoção
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>

            <SimulacaoResultado simulacao={simulacao.data} />
          </div>
        )}
      </section>
    </div>
  )
}

import { useNavigate } from 'react-router-dom'
import { Building2, Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import ImovelCard from '@/components/imovel/ImovelCard'
import FiltrosBusca from '@/components/imovel/FiltrosBusca'
import { useImoveis } from '@/hooks/useImoveis'

export default function ListaImoveisPage() {
  const navigate = useNavigate()
  const { items, loading, load, remove } = useImoveis({ autoLoad: true })

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-xl font-semibold text-slate-800">Imóveis</div>
          <div className="text-sm text-slate-500">Pesquise, compare e simule seus imóveis</div>
        </div>
        <Button
          className="bg-primary-600 hover:bg-primary-700 text-white"
          onClick={() => navigate('/imoveis/novo')}
        >
          <Plus className="mr-2 h-4 w-4" /> Novo imóvel
        </Button>
      </div>

      <FiltrosBusca disabled={loading} onSearch={(p) => load(p)} onClear={() => load(null)} />

      {loading ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="rounded-2xl bg-white shadow-sm p-4">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="mt-3 h-8 w-1/2" />
              <Skeleton className="mt-4 h-24 w-full" />
              <Skeleton className="mt-4 h-10 w-full" />
            </div>
          ))}
        </div>
      ) : items?.length ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {items.map((imovel) => (
            <ImovelCard key={imovel.id} imovel={imovel} onRemove={remove} />
          ))}
        </div>
      ) : (
        <div className="rounded-2xl bg-white shadow-sm p-10 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-50 text-primary-700">
            <Building2 className="h-6 w-6" />
          </div>
          <div className="mt-4 text-lg font-semibold text-slate-800">Nenhum imóvel encontrado</div>
          <div className="mt-1 text-sm text-slate-500">Ajuste os filtros ou cadastre um novo imóvel.</div>
          <Button
            variant="outline"
            className="mt-5 border-primary-600 text-primary-600 hover:bg-primary-50"
            onClick={() => navigate('/imoveis/novo')}
          >
            <Plus className="mr-2 h-4 w-4" /> Cadastrar imóvel
          </Button>
        </div>
      )}
    </div>
  )
}
